-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jul 06, 2024 at 08:51 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assessment9`
--

-- --------------------------------------------------------

--
-- Table structure for table `disease_master`
--

CREATE TABLE `disease_master` (
  `disease_id` int(11) NOT NULL,
  `disease_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `disease_master`
--

INSERT INTO `disease_master` (`disease_id`, `disease_name`) VALUES
(1, 'fever'),
(2, 'cold'),
(3, 'chicken pox'),
(4, 'misseles'),
(5, 'dengue'),
(6, 'cough');

-- --------------------------------------------------------

--
-- Table structure for table `patient_master`
--

CREATE TABLE `patient_master` (
  `patient_id` int(11) NOT NULL,
  `patient_name` varchar(40) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `phone_no` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient_master`
--

INSERT INTO `patient_master` (`patient_id`, `patient_name`, `gender`, `dob`, `phone_no`) VALUES
(1, 'rajalaxmi', 'female', '2001-01-17', '7735725956'),
(2, 'pooja', 'female', '2014-01-19', '12345'),
(3, 'amit', 'male', '2005-01-20', '1234'),
(4, 'ajit', 'male', '2000-01-23', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `prescription_tbl`
--

CREATE TABLE `prescription_tbl` (
  `prescription_id` int(11) NOT NULL,
  `doctor_name` varchar(40) NOT NULL,
  `date_of_visit` date NOT NULL,
  `patient_id` int(11) NOT NULL,
  `disease_id` int(11) NOT NULL,
  `prescription_details` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prescription_tbl`
--

INSERT INTO `prescription_tbl` (`prescription_id`, `doctor_name`, `date_of_visit`, `patient_id`, `disease_id`, `prescription_details`) VALUES
(1, 'Dr.Amit Singh', '2024-01-23', 1, 1, 'take 1 paracoetal after lunch'),
(2, 'Dr.Amit Singh', '2024-01-19', 1, 2, 'namcold tablet twice daily for 2 days.'),
(3, 'Dr.Amit Singh', '2024-01-16', 2, 4, 'take rest'),
(4, 'Dr.Amit Singh', '2024-01-13', 4, 6, 'take cough serup daily 3 times'),
(5, 'Dr.Amit Singh', '2024-01-25', 2, 1, 'take paracoetamol twice a day.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `disease_master`
--
ALTER TABLE `disease_master`
  ADD PRIMARY KEY (`disease_id`);

--
-- Indexes for table `patient_master`
--
ALTER TABLE `patient_master`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `prescription_tbl`
--
ALTER TABLE `prescription_tbl`
  ADD PRIMARY KEY (`prescription_id`),
  ADD KEY `fk_prescription_disease` (`disease_id`),
  ADD KEY `fk_prescription_patient` (`patient_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `disease_master`
--
ALTER TABLE `disease_master`
  MODIFY `disease_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `patient_master`
--
ALTER TABLE `patient_master`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `prescription_tbl`
--
ALTER TABLE `prescription_tbl`
  MODIFY `prescription_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `prescription_tbl`
--
ALTER TABLE `prescription_tbl`
  ADD CONSTRAINT `fk_prescription_disease` FOREIGN KEY (`disease_id`) REFERENCES `disease_master` (`disease_id`),
  ADD CONSTRAINT `fk_prescription_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient_master` (`patient_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

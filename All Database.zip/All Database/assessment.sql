-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jul 06, 2024 at 08:50 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assessment`
--

-- --------------------------------------------------------

--
-- Table structure for table `order_master`
--

CREATE TABLE `order_master` (
  `orderid` int(30) NOT NULL,
  `orderdate` date NOT NULL DEFAULT current_timestamp(),
  `prodid` int(11) NOT NULL,
  `prodrate` int(11) NOT NULL,
  `orderqty` int(11) NOT NULL,
  `ordervalue` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_master`
--

INSERT INTO `order_master` (`orderid`, `orderdate`, `prodid`, `prodrate`, `orderqty`, `ordervalue`) VALUES
(11, '2023-11-29', 1, 20, 20, 400),
(12, '2023-12-05', 3, 40, 20, 800),
(13, '2023-12-12', 3, 40, 20, 800),
(14, '2023-12-15', 1, 20, 2, 40),
(15, '2023-12-16', 0, 0, 0, 0),
(16, '2023-12-16', 0, 0, 0, 0),
(17, '2023-12-16', 0, 0, 0, 0),
(18, '2023-12-16', 3, 40, 2, 80),
(19, '2023-12-17', 3, 40, 7, 280),
(20, '2023-12-17', 3, 40, 3, 120),
(21, '2023-12-17', 3, 40, 3, 120),
(23, '2023-12-17', 1, 20, 2, 40),
(24, '2023-12-17', 1, 20, 2, 40),
(25, '2023-12-27', 4, 50, 7, 350),
(26, '2023-12-27', 1, 20, 200, 4000),
(27, '2023-12-27', 1, 20, 20, 400),
(43, '2023-12-28', 1, 20, 7, 140),
(44, '2024-01-16', 1, 20, 3, 60);

-- --------------------------------------------------------

--
-- Table structure for table `product_master`
--

CREATE TABLE `product_master` (
  `prodid` int(30) NOT NULL,
  `prodname` varchar(30) NOT NULL,
  `prodrate` int(30) NOT NULL,
  `prodqty` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_master`
--

INSERT INTO `product_master` (`prodid`, `prodname`, `prodrate`, `prodqty`) VALUES
(1, 'munch', 20, 200),
(2, 'fivestar', 30, 300),
(3, 'dairymilk', 40, 400),
(4, 'kitkat', 50, 500),
(5, 'perk', 60, 600);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `order_master`
--
ALTER TABLE `order_master`
  ADD PRIMARY KEY (`orderid`);

--
-- Indexes for table `product_master`
--
ALTER TABLE `product_master`
  ADD PRIMARY KEY (`prodid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order_master`
--
ALTER TABLE `order_master`
  MODIFY `orderid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `product_master`
--
ALTER TABLE `product_master`
  MODIFY `prodid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

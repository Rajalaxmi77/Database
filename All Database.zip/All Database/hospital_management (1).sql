-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2024 at 08:56 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_doctor`
--

CREATE TABLE `tbl_doctor` (
  `Doct_ID` int(11) NOT NULL,
  `Hosp_ID` int(11) NOT NULL,
  `Doct_Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_doctor`
--

INSERT INTO `tbl_doctor` (`Doct_ID`, `Hosp_ID`, `Doct_Name`) VALUES
(1, 1, 'Hara Mohan Mohanty'),
(2, 1, 'Sunil Choudhury'),
(3, 2, 'Bibhudutta Samal'),
(4, 2, 'Smruti Nayak'),
(5, 2, 'Sonali Sarakar'),
(6, 3, 'Sachin Sahoo'),
(7, 3, 'Kabita Tripathy'),
(8, 3, 'Komal Nath');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hospital`
--

CREATE TABLE `tbl_hospital` (
  `Hosp_ID` int(11) NOT NULL,
  `Hosp_Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_hospital`
--

INSERT INTO `tbl_hospital` (`Hosp_ID`, `Hosp_Name`) VALUES
(1, 'Kalinga Hospital'),
(2, 'Sum Hospital'),
(3, 'KIMS Hospital'),
(4, 'AMRI Hospital');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_insurance`
--

CREATE TABLE `tbl_insurance` (
  `Insurance_ID` int(11) NOT NULL,
  `Insurance_Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_insurance`
--

INSERT INTO `tbl_insurance` (`Insurance_ID`, `Insurance_Name`) VALUES
(1, 'BSKY'),
(2, 'ICICI Lombard'),
(3, 'Star Health');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_insurance_scheme`
--

CREATE TABLE `tbl_insurance_scheme` (
  `Insurance_Scheme_ID` int(11) NOT NULL,
  `Insurance_ID` int(11) NOT NULL,
  `Insurance_Scheme_Name` varchar(50) NOT NULL,
  `Insurance_Percentage_cover` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_insurance_scheme`
--

INSERT INTO `tbl_insurance_scheme` (`Insurance_Scheme_ID`, `Insurance_ID`, `Insurance_Scheme_Name`, `Insurance_Percentage_cover`) VALUES
(1, 1, '3LAC Plan', 60),
(2, 1, '5LAC Plan', 70),
(3, 1, '7LAC Plan', 80),
(4, 2, '3LAC Plan', 62),
(5, 2, '5LAC Plan', 75),
(6, 2, '7LAC Plan', 90),
(7, 3, '3LAC Plan', 60),
(8, 3, '5LAC Plan', 70),
(9, 3, '7LAC Plan', 80);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_patient`
--

CREATE TABLE `tbl_patient` (
  `Patient_ID` int(11) NOT NULL,
  `Doct_ID` int(11) NOT NULL,
  `Patient_Name` varchar(100) NOT NULL,
  `Patient_Phone` varchar(50) NOT NULL,
  `Insurance_Scheme_ID` int(11) NOT NULL,
  `Status` varchar(30) NOT NULL DEFAULT '"Active"||"Inactive"'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_patient`
--

INSERT INTO `tbl_patient` (`Patient_ID`, `Doct_ID`, `Patient_Name`, `Patient_Phone`, `Insurance_Scheme_ID`, `Status`) VALUES
(1, 1, 'Barsarani Mahapatra', '9777389809', 1, 'Inactive'),
(2, 2, 'Pramod Kumar Barik', '9861133155', 2, 'Inactive'),
(3, 3, 'Falguni Barik', '9776842628', 3, 'Active'),
(4, 4, 'Satyaprakash Mohanty', '7894656945', 4, 'Active'),
(5, 4, 'Sarat Kumar Sahoo', '6371097647', 5, 'Active'),
(6, 5, 'Adesh Patel', '7873670001', 6, 'Active'),
(7, 6, 'Ambika Prasad Barik', '8249598403', 7, 'Active'),
(8, 7, 'Aparna Priyadarshani', '8260391984', 8, 'Active'),
(9, 8, 'Arundhatti Mahapatra', '9439914183', 9, 'Active'),
(10, 1, 'Ashis Sharma', '9348068051', 3, 'Active'),
(11, 1, 'Ashutosh Mohanty', '8249054037', 5, 'Active'),
(12, 3, 'Balmukund Kumar', '8507891818', 7, 'Active'),
(13, 3, 'Barsha Rani Panda', '7894497766', 9, 'Active'),
(14, 5, 'Bidyadhar Muduli', '7077538280', 2, 'Active'),
(15, 5, 'Bishal Ghosh', '8274937670', 4, 'Active'),
(16, 6, 'Biswajit Samal', '9437456187', 6, 'Inactive'),
(17, 7, 'Biswarupa Nayak', '9113111918', 1, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_patient_details`
--

CREATE TABLE `tbl_patient_details` (
  `Patient_Details_ID` int(11) NOT NULL,
  `Patient_ID` int(11) NOT NULL,
  `Admission_Date` date NOT NULL,
  `Discharge_Date` date NOT NULL,
  `Total_Expenses` double NOT NULL,
  `Insured_amount` double NOT NULL,
  `Total_Payble_Amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_patient_details`
--

INSERT INTO `tbl_patient_details` (`Patient_Details_ID`, `Patient_ID`, `Admission_Date`, `Discharge_Date`, `Total_Expenses`, `Insured_amount`, `Total_Payble_Amount`) VALUES
(1, 1, '2024-06-06', '2024-06-14', 300000, 180000, 120000),
(2, 4, '2024-06-06', '2024-06-08', 20000, 12400, 7600);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_doctor`
--
ALTER TABLE `tbl_doctor`
  ADD PRIMARY KEY (`Doct_ID`),
  ADD KEY `fk_hospital_id` (`Hosp_ID`);

--
-- Indexes for table `tbl_hospital`
--
ALTER TABLE `tbl_hospital`
  ADD PRIMARY KEY (`Hosp_ID`);

--
-- Indexes for table `tbl_insurance`
--
ALTER TABLE `tbl_insurance`
  ADD PRIMARY KEY (`Insurance_ID`);

--
-- Indexes for table `tbl_insurance_scheme`
--
ALTER TABLE `tbl_insurance_scheme`
  ADD PRIMARY KEY (`Insurance_Scheme_ID`),
  ADD KEY `FK_Insurance_Scheme_Insurance_ID` (`Insurance_ID`);

--
-- Indexes for table `tbl_patient`
--
ALTER TABLE `tbl_patient`
  ADD PRIMARY KEY (`Patient_ID`),
  ADD KEY `FK_tbl_Patient_Doctor` (`Doct_ID`),
  ADD KEY `FK_tbl_Patient_InsuranceScheme` (`Insurance_Scheme_ID`);

--
-- Indexes for table `tbl_patient_details`
--
ALTER TABLE `tbl_patient_details`
  ADD PRIMARY KEY (`Patient_Details_ID`),
  ADD KEY `FK_tbl_Patient_Details_tbl_Patient` (`Patient_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_doctor`
--
ALTER TABLE `tbl_doctor`
  MODIFY `Doct_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_hospital`
--
ALTER TABLE `tbl_hospital`
  MODIFY `Hosp_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_insurance`
--
ALTER TABLE `tbl_insurance`
  MODIFY `Insurance_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_insurance_scheme`
--
ALTER TABLE `tbl_insurance_scheme`
  MODIFY `Insurance_Scheme_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_patient`
--
ALTER TABLE `tbl_patient`
  MODIFY `Patient_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_patient_details`
--
ALTER TABLE `tbl_patient_details`
  MODIFY `Patient_Details_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_doctor`
--
ALTER TABLE `tbl_doctor`
  ADD CONSTRAINT `fk_hospital_id` FOREIGN KEY (`Hosp_ID`) REFERENCES `tbl_hospital` (`Hosp_ID`);

--
-- Constraints for table `tbl_insurance_scheme`
--
ALTER TABLE `tbl_insurance_scheme`
  ADD CONSTRAINT `FK_Insurance_Scheme_Insurance_ID` FOREIGN KEY (`Insurance_ID`) REFERENCES `tbl_insurance` (`Insurance_ID`);

--
-- Constraints for table `tbl_patient`
--
ALTER TABLE `tbl_patient`
  ADD CONSTRAINT `FK_tbl_Patient_Doctor` FOREIGN KEY (`Doct_ID`) REFERENCES `tbl_doctor` (`Doct_ID`),
  ADD CONSTRAINT `FK_tbl_Patient_InsuranceScheme` FOREIGN KEY (`Insurance_Scheme_ID`) REFERENCES `tbl_insurance_scheme` (`Insurance_Scheme_ID`);

--
-- Constraints for table `tbl_patient_details`
--
ALTER TABLE `tbl_patient_details`
  ADD CONSTRAINT `FK_tbl_Patient_Details_tbl_Patient` FOREIGN KEY (`Patient_ID`) REFERENCES `tbl_patient` (`Patient_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

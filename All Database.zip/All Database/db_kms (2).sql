-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2024 at 08:56 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_kms`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attendance`
--

CREATE TABLE `tbl_attendance` (
  `AttendanceID` int(11) NOT NULL,
  `USERID` int(11) DEFAULT NULL,
  `AttendanceDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `IsPresent` bit(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_candidate_details`
--

CREATE TABLE `tbl_candidate_details` (
  `CandidateID` int(11) NOT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `PhoneNum` varchar(20) DEFAULT NULL,
  `Resume` blob DEFAULT NULL,
  `Adress` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_deserved_canditate`
--

CREATE TABLE `tbl_deserved_canditate` (
  `C_ID` int(11) NOT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `PhoneNum` varchar(20) DEFAULT NULL,
  `Resume` blob DEFAULT NULL,
  `Adress` varchar(255) DEFAULT NULL,
  `CandidateID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_emailtemplate`
--

CREATE TABLE `tbl_emailtemplate` (
  `template_id` int(11) NOT NULL,
  `template_name` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `template_body` text DEFAULT NULL,
  `CREATEDBY` int(11) DEFAULT NULL,
  `CREATEDON` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `UPDATEDBY` int(11) DEFAULT NULL,
  `UPDATEDON` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DELETEDFLAG` bit(1) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `USERID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee_swapping_history`
--

CREATE TABLE `tbl_employee_swapping_history` (
  `SwapId` int(11) NOT NULL,
  `USERID` int(11) DEFAULT NULL,
  `CurrentProjectName` varchar(255) DEFAULT NULL,
  `SwappedProject` varchar(255) DEFAULT NULL,
  `ProjectID` int(11) DEFAULT NULL,
  `SwappedDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_leavemaster`
--

CREATE TABLE `tbl_leavemaster` (
  `LeaveTypeID` int(11) NOT NULL,
  `LeaveTypeName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_modulemaster`
--

CREATE TABLE `tbl_modulemaster` (
  `MODULEID` int(11) NOT NULL,
  `MODULENAME` varchar(255) DEFAULT NULL,
  `MODULEDESCRIPTION` text DEFAULT NULL,
  `LOGO` varchar(255) DEFAULT NULL,
  `CREATEDBY` int(11) DEFAULT NULL,
  `CREATEDON` timestamp NOT NULL DEFAULT current_timestamp(),
  `UPDATEDBY` int(11) DEFAULT NULL,
  `UPDATEDON` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETEDFLAG` bit(1) DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_project_allocation_history`
--

CREATE TABLE `tbl_project_allocation_history` (
  `AllocateId` int(11) NOT NULL,
  `USERID` int(11) DEFAULT NULL,
  `CurrentProjectName` varchar(255) DEFAULT NULL,
  `OldProjectName` varchar(255) DEFAULT NULL,
  `AssignedDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `RemovalDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isActive` bit(1) DEFAULT NULL,
  `ProjectID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_project_master`
--

CREATE TABLE `tbl_project_master` (
  `ProjectID` int(11) NOT NULL,
  `ProjectName` varchar(255) DEFAULT NULL,
  `ProjectOrigin` varchar(100) NOT NULL,
  `ProjectDescription` varchar(500) DEFAULT NULL,
  `InsertDate` datetime NOT NULL,
  `InsertIpAddress` varchar(15) NOT NULL,
  `USERID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_project_master`
--

INSERT INTO `tbl_project_master` (`ProjectID`, `ProjectName`, `ProjectOrigin`, `ProjectDescription`, `InsertDate`, `InsertIpAddress`, `USERID`) VALUES
(1, 'KMS', 'State 2', 'Kwantify Management System', '2024-04-18 00:00:00', '127.0.0.1', NULL),
(2, 'Lms', 'State 3', 'rtrytuyiuou', '2024-04-18 00:00:00', '127.0.0.1', NULL),
(3, 'BSKY', 'State 1', 'rdyttguyhiu', '2024-04-18 00:00:00', '127.0.0.1', NULL),
(4, 'Mo Sarkar', 'State 1', 'tygyujhjk', '2024-04-18 00:00:00', '127.0.0.1', NULL),
(5, 'Mishan Sakti', 'State 3', 'vgvnbmnb', '2024-04-18 00:00:00', '127.0.0.1', NULL),
(6, 'Jana Sunani', 'State 1', 'bvhhjnjk', '2024-04-18 00:00:00', '127.0.0.1', NULL),
(8, 'Orera 2.0', 'State 2', 'bnjm,m', '2024-04-18 00:00:00', '127.0.0.1', NULL),
(9, 'Gosugam', 'State 1', 'tfytygyhiuj', '2024-04-19 00:00:00', '127.0.0.1', NULL),
(11, 'trytyu', 'State 1', 'dffhggjhjk', '2024-04-19 00:00:00', '127.0.0.1', NULL),
(18, 'rtfygyh', 'State 2', 'ghjhnjk', '2024-04-19 00:00:00', '127.0.0.1', NULL),
(20, 'tytuyu', 'State 2', 'uuijookpo', '2024-04-19 00:00:00', '127.0.0.1', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_salary`
--

CREATE TABLE `tbl_salary` (
  `SalaryID` int(11) NOT NULL,
  `USERID` int(11) DEFAULT NULL,
  `BasicSalary` decimal(10,0) DEFAULT NULL,
  `HRA` decimal(10,0) DEFAULT NULL,
  `PF` decimal(10,0) DEFAULT NULL,
  `ESI` decimal(10,0) DEFAULT NULL,
  `DA` decimal(10,0) DEFAULT NULL,
  `OtherAllowances` decimal(10,0) DEFAULT NULL,
  `TotalSalary` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_submodulemaster`
--

CREATE TABLE `tbl_submodulemaster` (
  `SUBMODULEID` int(11) NOT NULL,
  `MODULEID` int(11) DEFAULT NULL,
  `SUBMODULENAME` varchar(255) DEFAULT NULL,
  `CREATEDBY` int(11) DEFAULT NULL,
  `CREATEDON` timestamp NOT NULL DEFAULT current_timestamp(),
  `UPDATEDBY` int(11) DEFAULT NULL,
  `UPDATEDON` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETEDFLAG` bit(1) DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tleave`
--

CREATE TABLE `tbl_tleave` (
  `LeaveID` int(11) NOT NULL,
  `LeaveTypeID` int(11) DEFAULT NULL,
  `StartDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `EndDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Reason` varchar(255) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `USERID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `USERID` int(11) NOT NULL,
  `UPASSWORD` varchar(255) DEFAULT NULL,
  `FULLNAME` varchar(255) DEFAULT NULL,
  `CONTACTNO` int(11) DEFAULT NULL,
  `EMAILID` varchar(255) DEFAULT NULL,
  `DESIGNATION` varchar(255) DEFAULT NULL,
  `DEPARTMENT` varchar(255) DEFAULT NULL,
  `USERTYPEID` int(11) DEFAULT NULL,
  `CREATEDBY` int(11) DEFAULT NULL,
  `CREATEDON` timestamp NOT NULL DEFAULT current_timestamp(),
  `UPDATEDBY` int(11) DEFAULT NULL,
  `UPDATEDON` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETEDFLAG` bit(1) DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`USERID`, `UPASSWORD`, `FULLNAME`, `CONTACTNO`, `EMAILID`, `DESIGNATION`, `DEPARTMENT`, `USERTYPEID`, `CREATEDBY`, `CREATEDON`, `UPDATEDBY`, `UPDATEDON`, `DELETEDFLAG`) VALUES
(1, 'Raj@1234', NULL, NULL, 'admin@csm.tech', NULL, NULL, 1, NULL, '2024-04-15 04:15:28', NULL, '2024-04-18 18:29:05', b'0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users_log`
--

CREATE TABLE `tbl_users_log` (
  `ID` int(11) NOT NULL,
  `USERID` int(11) NOT NULL,
  `LOGIN_TIME` datetime NOT NULL,
  `LOGOUT_TIME` datetime NOT NULL,
  `LOGINTOKEN` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users_type`
--

CREATE TABLE `tbl_users_type` (
  `USERTYPEID` int(11) NOT NULL,
  `TYPENAME` varchar(255) DEFAULT NULL,
  `CREATEDBY` int(11) DEFAULT NULL,
  `CREATEDON` timestamp NOT NULL DEFAULT current_timestamp(),
  `UPDATEDBY` int(11) DEFAULT NULL,
  `UPDATEDON` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DELETEDFLAG` bit(1) DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users_type`
--

INSERT INTO `tbl_users_type` (`USERTYPEID`, `TYPENAME`, `CREATEDBY`, `CREATEDON`, `UPDATEDBY`, `UPDATEDON`, `DELETEDFLAG`) VALUES
(1, 'Admin', 1, '2024-04-15 04:12:02', NULL, '2024-04-15 04:12:02', b'0'),
(2, 'HR', 1, '2024-04-15 04:12:25', NULL, '2024-04-15 04:12:25', b'0'),
(3, 'Employee', 1, '2024-04-15 04:12:48', NULL, '2024-04-15 04:12:48', b'0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_work_order_details`
--

CREATE TABLE `tbl_work_order_details` (
  `WorkOrderID` int(11) NOT NULL,
  `ProjectID` int(11) DEFAULT NULL,
  `WorkOrderNo` varchar(50) NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `Description` varchar(500) DEFAULT NULL,
  `UploadWorkOrder` varchar(100) NOT NULL,
  `USERID` int(11) DEFAULT NULL,
  `isWorkorderSent` enum('Yes','No') NOT NULL DEFAULT 'No',
  `SentDate` datetime NOT NULL DEFAULT current_timestamp(),
  `isReceived` enum('Yes','No') NOT NULL,
  `receiveDate` datetime NOT NULL DEFAULT current_timestamp(),
  `receivedBy` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_work_order_details`
--

INSERT INTO `tbl_work_order_details` (`WorkOrderID`, `ProjectID`, `WorkOrderNo`, `StartDate`, `EndDate`, `Description`, `UploadWorkOrder`, `USERID`, `isWorkorderSent`, `SentDate`, `isReceived`, `receiveDate`, `receivedBy`) VALUES
(1, 1, 'OFD340', '2024-04-03', '2024-05-04', 'tryuiijoihvgc', 'C:\\fakepath\\ADMIN-MODULE-WORKORDER-DETAILS-MANAGE.pdf', NULL, 'No', '2024-04-25 12:42:18', 'Yes', '2024-04-25 12:43:28', 0),
(2, 2, 'AB001', '2024-04-04', '2024-04-19', 'hghgjhkjhiihj', 'C:\\fakepath\\ADMIN-SCREEN-V1 (1).pdf', NULL, 'No', '2024-04-25 12:42:18', 'Yes', '2024-04-25 12:43:28', 0),
(3, 2, 'AB002', '2024-04-02', '2024-11-28', 'lms project', 'C:\\fakepath\\ADMIN-SCREEN-V1.pdf', NULL, 'No', '2024-04-25 12:42:18', 'Yes', '2024-04-25 12:43:28', 0),
(4, 1, 'OFD341', '2024-04-03', '2024-05-04', 'tryuiijoihvgc', 'C:\\fakepath\\ADMIN-MODULE-WORKORDER-DETAILS-MANAGE.pdf', NULL, 'No', '2024-04-25 12:42:18', 'Yes', '2024-04-25 12:43:28', 0),
(5, 2, 'AB003', '2024-04-04', '2024-04-19', 'hghgjhkjhiihj', 'C:\\fakepath\\ADMIN-SCREEN-V1 (1).pdf', NULL, 'No', '2024-04-25 12:42:18', 'Yes', '2024-04-25 12:43:28', 0),
(6, NULL, 'BS456', '2024-04-06', '2024-05-12', 'hfytdfhfyju', 'C:\\fakepath\\ADMIN-MODULE-WORKORDER-DETAILS-MANAGE.pdf', NULL, 'No', '2024-04-25 12:42:18', 'Yes', '2024-04-25 12:43:28', 0),
(7, NULL, 'BS456', '2024-04-06', '2024-05-12', 'hfytdfhfyju', 'C:\\fakepath\\ADMIN-MODULE-WORKORDER-DETAILS-MANAGE.pdf', NULL, 'No', '2024-04-25 12:42:18', 'Yes', '2024-04-25 12:43:28', 0),
(8, NULL, 'BS456', '2024-04-06', '2024-05-12', 'hfytdfhfyju', 'C:\\fakepath\\ADMIN-MODULE-WORKORDER-DETAILS-MANAGE.pdf', NULL, 'No', '2024-04-25 12:42:18', 'Yes', '2024-04-25 12:43:28', 0),
(9, 1, 'OFD342', '2024-04-03', '2024-05-04', 'tryuiijoihvgc', 'C:\\fakepath\\ADMIN-MODULE-WORKORDER-DETAILS-MANAGE.pdf', NULL, 'No', '2024-04-25 12:42:18', 'Yes', '2024-04-25 12:43:28', 0),
(10, 2, 'AB004', '2024-04-03', '2024-04-28', 'hhjjkjklkljkljkj', 'C:\\fakepath\\ADMIN-MODULE-WORKORDER-DETAILS-MANAGE.pdf', NULL, 'No', '2024-04-25 12:42:18', 'Yes', '2024-04-25 12:43:28', 0),
(11, NULL, 'BS456', '2024-04-06', '2024-05-12', 'hfytdfhfyju', 'C:\\fakepath\\ADMIN-MODULE-WORKORDER-DETAILS-MANAGE.pdf', NULL, 'No', '2024-04-25 12:42:18', 'Yes', '2024-04-25 12:43:28', 0),
(12, 1, 'OFD343', '2024-04-03', '2024-05-04', 'tryuiijoihvgc', 'C:\\fakepath\\ADMIN-MODULE-WORKORDER-DETAILS-MANAGE.pdf', NULL, 'No', '2024-04-25 12:42:18', 'Yes', '2024-04-25 12:43:28', 0),
(13, NULL, 'BS456', '2024-04-06', '2024-05-12', 'hfytdfhfyju', 'C:\\fakepath\\ADMIN-MODULE-WORKORDER-DETAILS-MANAGE.pdf', NULL, 'No', '2024-04-29 10:21:40', 'Yes', '2024-04-29 10:21:40', 0),
(14, 5, 'ZX123', '2024-04-29', '2024-05-10', 'vhvcusygcusygu', 'C:\\fakepath\\ADMIN-MODULE-WORKORDER-DETAILS-MANAGE.pdf', NULL, 'No', '2024-04-29 11:35:35', 'Yes', '2024-04-29 11:35:35', 0),
(15, 8, 'ore234', '2024-05-04', '2024-05-12', 'hbjhkjhk,jhil', 'C:\\fakepath\\ADMIN-SCREEN-V1 (1).pdf', NULL, 'No', '2024-04-29 17:15:15', 'Yes', '2024-04-29 17:15:15', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  ADD PRIMARY KEY (`AttendanceID`),
  ADD KEY `USERID` (`USERID`);

--
-- Indexes for table `tbl_candidate_details`
--
ALTER TABLE `tbl_candidate_details`
  ADD PRIMARY KEY (`CandidateID`);

--
-- Indexes for table `tbl_deserved_canditate`
--
ALTER TABLE `tbl_deserved_canditate`
  ADD PRIMARY KEY (`C_ID`),
  ADD KEY `CandidateID` (`CandidateID`);

--
-- Indexes for table `tbl_emailtemplate`
--
ALTER TABLE `tbl_emailtemplate`
  ADD PRIMARY KEY (`template_id`),
  ADD KEY `USERID` (`USERID`);

--
-- Indexes for table `tbl_employee_swapping_history`
--
ALTER TABLE `tbl_employee_swapping_history`
  ADD PRIMARY KEY (`SwapId`),
  ADD KEY `USERID` (`USERID`),
  ADD KEY `ProjectID` (`ProjectID`);

--
-- Indexes for table `tbl_leavemaster`
--
ALTER TABLE `tbl_leavemaster`
  ADD PRIMARY KEY (`LeaveTypeID`);

--
-- Indexes for table `tbl_modulemaster`
--
ALTER TABLE `tbl_modulemaster`
  ADD PRIMARY KEY (`MODULEID`);

--
-- Indexes for table `tbl_project_allocation_history`
--
ALTER TABLE `tbl_project_allocation_history`
  ADD PRIMARY KEY (`AllocateId`),
  ADD KEY `USERID` (`USERID`),
  ADD KEY `ProjectID` (`ProjectID`);

--
-- Indexes for table `tbl_project_master`
--
ALTER TABLE `tbl_project_master`
  ADD PRIMARY KEY (`ProjectID`),
  ADD KEY `USERID` (`USERID`);

--
-- Indexes for table `tbl_salary`
--
ALTER TABLE `tbl_salary`
  ADD PRIMARY KEY (`SalaryID`),
  ADD KEY `USERID` (`USERID`);

--
-- Indexes for table `tbl_submodulemaster`
--
ALTER TABLE `tbl_submodulemaster`
  ADD PRIMARY KEY (`SUBMODULEID`),
  ADD KEY `MODULEID` (`MODULEID`);

--
-- Indexes for table `tbl_tleave`
--
ALTER TABLE `tbl_tleave`
  ADD PRIMARY KEY (`LeaveID`),
  ADD KEY `LeaveTypeID` (`LeaveTypeID`),
  ADD KEY `USERID` (`USERID`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`USERID`),
  ADD UNIQUE KEY `EMAILID` (`EMAILID`),
  ADD KEY `USERTYPEID` (`USERTYPEID`);

--
-- Indexes for table `tbl_users_log`
--
ALTER TABLE `tbl_users_log`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_users_type`
--
ALTER TABLE `tbl_users_type`
  ADD PRIMARY KEY (`USERTYPEID`),
  ADD UNIQUE KEY `USERTYPEID` (`USERTYPEID`);

--
-- Indexes for table `tbl_work_order_details`
--
ALTER TABLE `tbl_work_order_details`
  ADD PRIMARY KEY (`WorkOrderID`),
  ADD KEY `ProjectID` (`ProjectID`),
  ADD KEY `USERID` (`USERID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_project_master`
--
ALTER TABLE `tbl_project_master`
  MODIFY `ProjectID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_users_log`
--
ALTER TABLE `tbl_users_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_work_order_details`
--
ALTER TABLE `tbl_work_order_details`
  MODIFY `WorkOrderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  ADD CONSTRAINT `tbl_attendance_ibfk_1` FOREIGN KEY (`USERID`) REFERENCES `tbl_users` (`USERID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_deserved_canditate`
--
ALTER TABLE `tbl_deserved_canditate`
  ADD CONSTRAINT `tbl_deserved_canditate_ibfk_1` FOREIGN KEY (`CandidateID`) REFERENCES `tbl_candidate_details` (`CandidateID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_emailtemplate`
--
ALTER TABLE `tbl_emailtemplate`
  ADD CONSTRAINT `tbl_emailtemplate_ibfk_1` FOREIGN KEY (`USERID`) REFERENCES `tbl_users` (`USERID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_employee_swapping_history`
--
ALTER TABLE `tbl_employee_swapping_history`
  ADD CONSTRAINT `tbl_employee_swapping_history_ibfk_1` FOREIGN KEY (`USERID`) REFERENCES `tbl_users` (`USERID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_employee_swapping_history_ibfk_2` FOREIGN KEY (`ProjectID`) REFERENCES `tbl_project_master` (`ProjectID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_project_allocation_history`
--
ALTER TABLE `tbl_project_allocation_history`
  ADD CONSTRAINT `tbl_project_allocation_history_ibfk_1` FOREIGN KEY (`USERID`) REFERENCES `tbl_users` (`USERID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_project_allocation_history_ibfk_2` FOREIGN KEY (`ProjectID`) REFERENCES `tbl_project_master` (`ProjectID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_project_master`
--
ALTER TABLE `tbl_project_master`
  ADD CONSTRAINT `tbl_project_master_ibfk_1` FOREIGN KEY (`USERID`) REFERENCES `tbl_users` (`USERID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_salary`
--
ALTER TABLE `tbl_salary`
  ADD CONSTRAINT `tbl_salary_ibfk_1` FOREIGN KEY (`USERID`) REFERENCES `tbl_users` (`USERID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_submodulemaster`
--
ALTER TABLE `tbl_submodulemaster`
  ADD CONSTRAINT `tbl_submodulemaster_ibfk_1` FOREIGN KEY (`MODULEID`) REFERENCES `tbl_modulemaster` (`MODULEID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_tleave`
--
ALTER TABLE `tbl_tleave`
  ADD CONSTRAINT `tbl_tleave_ibfk_1` FOREIGN KEY (`LeaveTypeID`) REFERENCES `tbl_leavemaster` (`LeaveTypeID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_tleave_ibfk_2` FOREIGN KEY (`USERID`) REFERENCES `tbl_users` (`USERID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD CONSTRAINT `tbl_users_ibfk_1` FOREIGN KEY (`USERTYPEID`) REFERENCES `tbl_users_type` (`USERTYPEID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_work_order_details`
--
ALTER TABLE `tbl_work_order_details`
  ADD CONSTRAINT `tbl_work_order_details_ibfk_1` FOREIGN KEY (`ProjectID`) REFERENCES `tbl_project_master` (`ProjectID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_work_order_details_ibfk_2` FOREIGN KEY (`USERID`) REFERENCES `tbl_users` (`USERID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
